import { Component, OnInit, ViewChild, Input, Output, EventEmitter } from '@angular/core';
import { BaseChartDirective, Label } from 'ng2-charts';
import { ChartConfiguration, ChartType, ChartOptions, ChartData, ChartDataSets } from 'chart.js';
import  * as pluginDataLabels from 'chartjs-plugin-datalabels';
@Component({
  selector: 'app-horizontal-chart',
  templateUrl: './horizontal-chart.component.html',
  styleUrls: ['./horizontal-chart.component.scss']
})
export class HorizontalChartComponent implements OnInit {
  @ViewChild(BaseChartDirective) chart: BaseChartDirective | undefined;
  @Input() chartCategoriesData: any;
  @Output() searchSubCategoryEmitter = new EventEmitter<any>();

  public chartPlugins = [pluginDataLabels];
  public chartjsChartOptionsObj: any;//ChartOptions;
  public barChartLabels: Label[];
  public barChartType: ChartType = 'horizontalBar';
  public barChartLegend = true;
  public barChartPlugins = [];

  public barChartData: ChartDataSets[];

  chartjsChartOptions: any;

  constructor() {

  }

  ngOnInit() {
  }

  ngOnChanges() {
    this.CategoriesChart();
  }

  CategoriesChart() {
    this.chartjsChartOptionsObj = {
      responsive: true,
      maintainAspectRatio: false,
      hover: {
        animationDuration: 500
      },
      tooltips:{
        enabled : true,
      },
      title: {
        text: this.chartCategoriesData?.chartHeading,
        display: true,
        fontSize: 16,
        fontColor: '#565656'
      },
      plugins: {
        datalabels: {
          anchor: "end",
          align: "end",
          color: '#565656',
          display: true,
          font: {
            size: 16,
            weight: "bold"
          },
        }
      },
      layout:{
        padding: {
          left: 0,
          right: 50,
          top: 20,
          bottom: 0
      }
      },
      legend: {
        display: false,
        labels: {
          fontColor: 'rgb(255, 99, 132)'
        }
      },
      scales:{
        xAxes:[{
          grid: {
            drawTicks: false
          },
          offset: false,
          stacked: true,
          ticks: {
            padding: 0,
            beginAtZero: true,
            display: true,
        },
          gridLines:{
            offsetGridLines: false,
            display:true,
            borderDash: [7, 3],
            color: "rgba(112, 112, 112, .4)",
          },
        }],
        yAxes:[{
          grid: {
            drawTicks: false
          },
          offset: true,
          stacked: true,
          ticks: {
            padding: 0,
            beginAtZero: true,
            display: true,
          },
          gridLines:{
            offsetGridLines: false,
            display: false,
            borderDash: [1, 3],
            color: "#b3b3b3"
          }
        }],
      }
    }

    this.barChartLabels = this.chartCategoriesData?.chartLabels ? this.chartCategoriesData?.chartLabels : [];
    this.barChartData = [
      {
        data: this.chartCategoriesData?.chartDatas ? this.chartCategoriesData?.chartDatas : [],
        barThickness: 30,
        backgroundColor: ['#4dc9f6', '#f67019', '#f53794', '#537bc4'],
        hoverBackgroundColor: ['#4dc9f6', '#f67019', '#f53794', '#537bc4']
      },
    ];

    this.chartjsChartOptions  = {
      ChartLabels: this.barChartLabels,
      barChartType: this.barChartType,
      barChartLegend: this.barChartLegend,
      barChartPlugins: this.barChartPlugins,
      barChartData: this.barChartData,
      chartOptions: this.chartjsChartOptionsObj,
      }

  }

  ChartHovered(event: any) {
  }

  ChartClicked(event: any) {
    if (this.chartCategoriesData?.chartType == 'main') {
      let selectedIndex = event?.['active'][0]?.['_index'];
      this.searchSubCategoryEmitter.emit(selectedIndex);  
    }
  }


}
