import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ChartService {
  BASEURL = 'http://65.1.73.181:3001';
  constructor(
    private http: HttpClient
  ) { }

  GetMainChart(dateRange) {
    return this.http.post(`${this.BASEURL}/api/v1.0/master/CategoryStatistics`, dateRange);
  }

  GetSubCategory(dateRange) {
    return this.http.post(`${this.BASEURL}/api/v1.0/master/SubCategoryStatistics`, dateRange);
  }

}