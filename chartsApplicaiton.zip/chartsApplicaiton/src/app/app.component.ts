import { Component, OnInit, OnDestroy } from '@angular/core';
import { ChartService } from './services/chart.service';
import { Subscription } from 'rxjs';
import { FormGroup, FormControl } from '@angular/forms';
import * as moment from 'moment';
import { retry } from 'rxjs/operators';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, OnDestroy {
  title = 'chartsApplicaiton';
  categoriesChart: Subscription;
  chartCategoriesData: any;
  apiChartResponse: any;
  subCategoriesChart: Subscription;
  chartSubCategoriesData: any;
  subCategoriesChartResponse: any;
  subCategoryHeading: any;
  range = new FormGroup({
    start: new FormControl(),
    end: new FormControl()
  });
  range1 = new FormGroup({
    start: new FormControl(),
    end: new FormControl()
  });

  constructor(
    private chartService: ChartService,
    public toast: ToastrService
  ) {

  }

  ngOnInit() {
    this.GetCategoriesChart();
  }

  GetCategoriesChart(dateRange?:any) {
    let requestObj = {
      FromDate: dateRange?.start ? dateRange?.start : "2021-06-09",
      ToDate: dateRange?.end ? dateRange?.end : "2021-06-10"
    }
   this.categoriesChart = this.chartService.GetMainChart(requestObj).pipe(retry(2)).subscribe((response: any)=> {
      if (response?.message == "Success") {
        let chartResponse = response?.responseData;
        this.apiChartResponse = response?.responseData;

        let chartLabels = chartResponse.map(data=> data?.CategoryName);
        let chartDatas = chartResponse.map(data=> data?.AmountSpent);
        let chartHeading = 'Categories Dashboard';
        let chartType = 'main';
        this.chartCategoriesData = {chartLabels, chartDatas, chartHeading, chartType};
      }
    }, (err)=> {
      this.apiChartResponse = [];
      console.log('err', err);
      this.toast.warning('Something Went Worng', 'Please Try again Later');
    }, ()=> {})
  }

  triggerSubCategoryChart(event) {
    let selectedCategory = this.apiChartResponse.find((data, index) => index == event);
    let requestObj = {
      FromDate:"2021-06-09",
      ToDate:"2021-06-10",
      CategoryId: selectedCategory?.CategoryId
    }
   this.subCategoriesChart = this.chartService.GetSubCategory(requestObj).pipe().subscribe((response: any)=> {
      if (response?.message == "Success") {
        let chartResponse = response?.responseData;
        this.subCategoriesChartResponse = response?.responseData;
        this.subCategoryHeading = selectedCategory?.CategoryName;
        let chartLabels = chartResponse.map(data=> data?.SubCategoryName);
        let chartDatas = chartResponse.map(data=> data?.AmountSpent);
        let chartHeading = 'Sub Categories Dashboard for ' + selectedCategory?.CategoryName;
        let chartType = 'sub';
        this.chartSubCategoriesData = {chartLabels, chartDatas, chartHeading, chartType};
      }
    }, (err)=> {
      console.log('err', err);
    }, ()=> {})
  }

  rangePicker(picker) {
    if (this.range.value.start && this.range.value.end) {
      const momentStartDate = new Date(this.range.value.start);
      const momentEndDate = new Date(this.range.value.end);
      const formattedStartDate = moment(momentStartDate).format("YYYY-MM-DD");
      const formattedEndDate = moment(momentEndDate).format("YYYY-MM-DD");
      console.log(formattedStartDate, formattedEndDate);
      let date = {start: formattedStartDate, end: formattedEndDate};
      this.GetCategoriesChart(date);
    }
  }

  rangePickerForSubCategory(picker) {
    if (this.range.value.start && this.range.value.end) {
      const momentStartDate = new Date(this.range.value.start);
      const momentEndDate = new Date(this.range.value.end);
      const formattedStartDate = moment(momentStartDate).format("YYYY-MM-DD");
      const formattedEndDate = moment(momentEndDate).format("YYYY-MM-DD");
      console.log(formattedStartDate, formattedEndDate);
      let date = {start: formattedStartDate, end: formattedEndDate};
      this.GetCategoriesChart(date);
    }
  }


  ngOnDestroy() {
    this.categoriesChart ? this.categoriesChart.unsubscribe() : '';
    this.subCategoriesChart ? this.subCategoriesChart.unsubscribe() : '';
  }
}
